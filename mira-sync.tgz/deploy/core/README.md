# Core Deploy

## Purpose

This directory will hold deployment notes for the smallest Mira core runtime.

## Owns

- core-only deployment guidance
- environment expectations for core
- release-safe deploy entrypoints

## Planned Contents

- local core setup
- required config references
- minimal service dependencies

## Current Status

This directory now marks the first concrete deploy path for a core-only release setup.

The automated local pack companion now lives at:

- [../mira-openclaw/README.md](../mira-openclaw/README.md)

Unified deploy comparison:

- [../deploy-paths-overview.md](../deploy-paths-overview.md)

## Minimal Core Deploy Inputs

Use these two files together:

- [core/openclaw-config/openclaw.example.json](../../core/openclaw-config/openclaw.example.json)
- [env.example](./env.example)
- [core/plugins/lingzhu-bridge/README.md](../../core/plugins/lingzhu-bridge/README.md)

The config example defines:

- provider placeholder shape
- workspace path
- timezone
- compaction mode
- baseline tool profile
- the release-safe `lingzhu` core plugin entry

The env template defines:

- where the OpenClaw runtime should read config from
- which workspace path the release core expects
- which provider secret still needs operator input

## Core-Only Deployment Story

This is the intended order:

1. install and prepare an OpenClaw runtime outside this release tree
2. copy and adapt [openclaw.example.json](../../core/openclaw-config/openclaw.example.json)
3. make [core/plugins/lingzhu-bridge](../../core/plugins/lingzhu-bridge) available to the target OpenClaw runtime
4. copy and adapt [env.example](./env.example)
5. point the runtime at [core/workspace](../../core/workspace)
6. verify the runtime loads Mira core and the release-safe `lingzhu` plugin without any first-party modules

Root-level generated-pack flow:

```bash
npm run bootstrap:mira-openclaw
npm run doctor:mira-openclaw
```

If the local machine already has `openclaw` installed, that generated-pack flow now installs the bundled `lingzhu` plugin shell into a repo-local OpenClaw state dir and validates the generated config through the real CLI.

